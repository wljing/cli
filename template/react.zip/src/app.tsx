import React from 'react';
import ReactDom from 'react-dom';
import Router from './router';

ReactDom.render(<div>asd</div>, document.querySelector('#root'));